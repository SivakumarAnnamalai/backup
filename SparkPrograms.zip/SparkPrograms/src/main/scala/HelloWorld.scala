/**
  * Created by siva on 4/30/16.
  */
object HelloWorld extends App{

  //def main(args:Array[String]): Unit ={
    println("Hello World")

    var l1 = List("hello Spark","Map Reduce")
    println(l1.map(x=>x.split(" ")))
    println(l1.flatMap(x=>x.split(" ")))
  //}

}

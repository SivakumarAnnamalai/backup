package test

/**
  * Created by siva on 5/9/16.
  */
class Test {

  private def m1: String = {
    return "Hello"
  }
}
  object Test {
    def main(args: Array[String]): Unit = {
      val obj1 = new Test()
      println(obj1.m1)
    }
  }


package test

import org.apache.spark.sql.SQLContext
import org.apache.spark.{SparkConf, SparkContext}
import com.databricks.spark.xml

/**
  * Created by siva on 5/9/16.
  */
  object Test {
    def main(args: Array[String]): Unit = {
      val conf = new SparkConf()
      conf.setMaster("local")
      conf.setAppName("Wordcount")
      val sc = new SparkContext(conf)
      /*sc.setLogLevel("WARN")
      val inputRDD = sc.textFile("/home/bigdata/test.txt")
      val wordsRDD = inputRDD.flatMap(x=>x.split(" "))
      val wordsPairRDD = wordsRDD.map(word=>(word,1))
      val wordCountRDD = wordsPairRDD.reduceByKey((x,y)=>x+y)
      wordCountRDD.collect().foreach(println)*/

      val sqlContext = new SQLContext(sc);
      import sqlContext.implicits
      val df1 = sqlContext.read.format("csv").load("/home/bigdata/customer_mapping.txt")
      df1.show
    }
  }


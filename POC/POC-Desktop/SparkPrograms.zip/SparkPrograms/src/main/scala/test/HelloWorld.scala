package test

/**
  * Created by siva on 4/30/16.
  */
object HelloWorld extends App{

  //def main(args:Array[String]): Unit ={
    println("Hello World")


  //}

}

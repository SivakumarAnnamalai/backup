import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableOutputFormat;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.filecache.DistributedCache;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.net.URI;
import java.net.URISyntaxException;
/**
 * Created by siva on 6/16/16.
 */
public class MRToHBaseV3 {
    public static class HMapper extends Mapper<LongWritable,Text,ImmutableBytesWritable, Put>{

        String COLUMN_FAMILY = "cf1";
        String COLUMN_QUALIFIER_1 = "City";
        String COLUMN_QUALIFIER_2 = "FirstName";
        String COLUMN_QUALIFIER_3 = "TransactionAmount";
        String COLUMN_QUALIFIER_4 = "StreetName";

        Properties properties ;
        String cacheFileName = "/customer_mapping.txt";
        String cacheFileLocation;

        MultipleOutputs<Text,NullWritable> multipleOutputs;

        public void setup(Context context) throws IOException {
            Path paths[] = DistributedCache.getLocalCacheFiles(context.getConfiguration());
            for(Path path:paths){
                if(path.toString().contains(cacheFileName)){
                    cacheFileLocation = path.toString();
                }
            }
            properties = new Properties();
            properties.load(new FileInputStream(cacheFileLocation));

            multipleOutputs =  new MultipleOutputs(context);
        }



        public void map(LongWritable key,Text value,Context context) throws IOException, InterruptedException {

            String data[] = value.toString().split(",");
            byte[] rowkey = data[0].getBytes();
            byte[] transactionAmount = data[1].getBytes();
            byte[] streetName = data[3].getBytes();
            byte[] city = data[4].getBytes();
            byte[] firstname = properties.getProperty(data[0],"NA").getBytes();
            Put p = new Put(rowkey);
            p.add(COLUMN_FAMILY.getBytes(),COLUMN_QUALIFIER_1.getBytes(),city);
            p.add(COLUMN_FAMILY.getBytes(),COLUMN_QUALIFIER_3.getBytes(),transactionAmount);
            p.add(COLUMN_FAMILY.getBytes(),COLUMN_QUALIFIER_2.getBytes(),firstname);
            p.add(COLUMN_FAMILY.getBytes(),COLUMN_QUALIFIER_4.getBytes(),streetName);
            context.write(new ImmutableBytesWritable(rowkey),p);
            multipleOutputs.write("hiveOutput",new Text(data[0]+" "+data[1]+" "+data[3]+" "+data[4]),NullWritable.get());

        }

        @Override
        public void cleanup(Context context) throws IOException, InterruptedException {
            multipleOutputs.close();
        }

    }

    public static void main(String args[]) throws IOException, ClassNotFoundException, InterruptedException, URISyntaxException {

        String table = "customer";
        Configuration conf = HBaseConfiguration.create();
        conf.set(TableOutputFormat.OUTPUT_TABLE,table);
        Job job = Job.getInstance(conf);

        job.setMapperClass(HMapper.class);
        job.setNumReduceTasks(0);
        job.setJarByClass(MRToHBaseV3.class);

        job.setOutputFormatClass(TableOutputFormat.class);
        job.setOutputKeyClass(ImmutableBytesWritable.class);
        job.setOutputValueClass(Writable.class);

        FileInputFormat.addInputPath(job,new Path(args[0]));
        FileOutputFormat.setOutputPath(job,new Path(args[1]));
        DistributedCache.addCacheFile(new URI("/customer_mapping.txt"),job.getConfiguration());
        MultipleOutputs.addNamedOutput(job, "hiveOutput", TextOutputFormat.class, Text.class, NullWritable.class);
        job.waitForCompletion(true);



    }
}
